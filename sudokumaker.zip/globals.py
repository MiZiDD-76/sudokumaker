class GLOBALS:
    scr_w = 1024
    scr_h = 768
    tile_w = int(scr_h / 9)
